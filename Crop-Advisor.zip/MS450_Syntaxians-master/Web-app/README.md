# crop-advisor
A Intelligent portal for farmers and government officials to predict the crop production and weather forecast


# To Intialize the Web app run 

npm install 
