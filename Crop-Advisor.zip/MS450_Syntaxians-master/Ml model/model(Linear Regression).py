import pandas as pd
#import matplotlib.pyplot as plt
#import seaborn as sns
#import numpy as np
import pickle
from sklearn.linear_model import LinearRegression
#from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split

df = pd.read_csv("./crop_production.csv")
df[:5]

"""
# Data Exploration
"""

df.isnull().sum()

# Droping Nan Values
data = df.dropna()
print(data.shape)
test = df[~df["Production"].notna()].drop("Production",axis=1)

for i in data.columns:
    print("column name :",i)
    print("No. of column :",len(data[i].unique()))
    print(data[i].unique())

sum_maxp = data["Production"].sum()
data["percent_of_production"] = data["Production"].map(lambda x:(x/sum_maxp)*100)

data[:5]

"""
# Feature Selection
"""

data1 = data.drop(["District_Name","Crop_Year"],axis=1)

data_dum = pd.get_dummies(data1)
data_dum[:5]

"""
# Test Train Split
"""

x = data_dum.drop("Production",axis=1)
y = data_dum[["Production"]]

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=42)

x_train[:5]

"""
Linear Regression
"""

model = LinearRegression()
model.fit(x_train,y_train)

pickle.dump( model , open ('model.pkl','wb'))


preds = model.predict(x_test)

mean_squared_error(y_test,preds)
score = r2_score(y_test,preds)


