import * as firebase from 'firebase';

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDjZjHKVwyTNwStfsyPCOPCB85UPwxXihs",
    authDomain: "crop-advisor-syntaxians.firebaseapp.com",
    databaseURL: "https://crop-advisor-syntaxians.firebaseio.com",
    projectId: "crop-advisor-syntaxians",
    storageBucket: "crop-advisor-syntaxians.appspot.com",
    messagingSenderId: "404636054051",
    appId: "1:404636054051:web:c4a37b8062ea9800017796",
    measurementId: "G-NG2ZZNEH50"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  var db = firebase.firestore();

  export const auth = firebase.auth()
  export const firestore = firebase.firestore
  export default db;